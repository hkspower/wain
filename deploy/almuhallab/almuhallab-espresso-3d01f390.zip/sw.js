/* Almuhallab v120 service worker — remediated public shell. */
"use strict";

var CACHE = "almuhallab-v122-espresso1";
var ASSETS = [
  "index.html",
  "home-v8.css",
  "home-v7.js",
  "theme-overrides-v2.css",
  "site-shared-v5.css",
  "layout-accessibility-v87.css",
  "side-spacing-v97.css",
  "theme-polish-v103.css",
  "responsive-v104.css",
  "topbar-v105.css",
  "light-body-v106.css",
  "business-portfolio-v1.css",
  "theme-v120.css",
  "sporta-logo.png",
  "sporta-og-image.png",
  "wain-logo.svg",
  "wain-preview.jpg",
  "main-menu-v98.js",
  "sw-update-v87.js",
  "service-base-v3.css",
  "service-shared-v2.js",
  "salon-queue-v87.js",
  "redirect-v87.js",
  "logo-amber-terminal.png",
  "logo-footer-transparent-no-glow-v83.svg",
  "almuhallab-social-card-v2-1200x630.png",
  "404.html",
  "%D8%AA%D8%B5%D9%85%D9%8A%D9%85-%D9%85%D9%88%D8%A7%D9%82%D8%B9/",
  "%D8%AA%D8%B7%D8%A8%D9%8A%D9%82%D8%A7%D8%AA-%D8%A7%D9%84%D8%AC%D9%88%D8%A7%D9%84/",
  "%D9%85%D9%88%D8%B8%D9%81-%D8%B0%D9%83%D8%A7%D8%A1-%D8%A7%D8%B5%D8%B7%D9%86%D8%A7%D8%B9%D9%8A/",
  "%D8%AA%D8%B5%D9%85%D9%8A%D9%85-%D8%B4%D8%B9%D8%A7%D8%B1/",
  "icon-v2.svg",
  "favicon-v2.svg",
  "fonts/cairo-400.woff2",
  "fonts/cairo-500.woff2",
  "fonts/cairo-600.woff2",
  "fonts/cairo-700.woff2",
  "fonts/cairo-800.woff2",
  "fonts/cairo-latin.woff2",
  "icon-v2-192.png",
  "icon-v2-512.png",
  "icon-v2-maskable-512.png",
  "apple-touch-icon-v2.png",
  "fonts/chakrapetch-600.woff2",
  "fonts/chakrapetch-700.woff2",
  "fonts/jetbrainsmono-latin.woff2",
];

var CACHE_PATHS = ASSETS.map(function (asset) {
  return new URL(asset, self.location.href).pathname;
});

function isCacheablePath(pathname) {
  return CACHE_PATHS.indexOf(pathname) !== -1;
}

function canonicalCacheKey(url) {
  /* Version query strings select fresh HTTP responses, but each reviewed
     asset owns one Cache Storage entry. Keeping the query would add another
     copy on every cache-busting visit. */
  return url.origin + url.pathname;
}

function replayableCachedResponse(response) {
  /* Hostinger redirects /index.html to /. Cache Storage keeps that redirect
     history even though the stored response is a final 200. A navigation
     request uses redirect mode "manual", so Chromium rejects the redirected
     cached response when it is replayed offline. Rebuild only those responses
     as plain same-origin responses. Cache bodies are already decoded, hence
     the encoded size/encoding headers must not be copied. */
  if (!response || !response.redirected) return Promise.resolve(response);
  var headers = new Headers(response.headers);
  headers.delete("content-encoding");
  headers.delete("content-length");
  return response.blob().then(function (body) {
    return new Response(body, {
      status: response.status,
      statusText: response.statusText,
      headers: headers,
    });
  });
}

function isPrivatePath(pathname) {
  return pathname.endsWith(".php") ||
    pathname === "/admin.html" || pathname.startsWith("/admin/") ||
    pathname === "/mcp-admin.html" || pathname.startsWith("/mcp-admin/") ||
    pathname === "/editor.html" || pathname.startsWith("/editor/");
}

function isPublicResponse(response) {
  if (!response || !response.ok) return false;
  var control = (response.headers.get("Cache-Control") || "").toLowerCase();
  return control.indexOf("private") === -1 &&
    control.indexOf("no-store") === -1 &&
    !response.headers.has("Set-Cookie");
}

self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(CACHE).then(function (cache) {
      /* cache: "reload" goes past the browser's HTTP cache: images and fonts
         are served with a week's max-age, so a plain addAll stored a returning
         visitor's stale icons or fonts under the new cache name */
      return cache.addAll(ASSETS.map(function (u) { return new Request(u, { cache: "reload" }); }));
    }).then(function () {
      return self.skipWaiting();
    })
  );
});

self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })
      );
    }).then(function () {
      return self.clients.claim();
    })
  );
});

self.addEventListener("fetch", function (event) {
  var req = event.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  /* Account, administration and authorized responses must come from the server. */
  if (isPrivatePath(url.pathname) || req.headers.has("Authorization")) return;

  /* Documents are network-first so a previous offline shell cannot hide a
     newly deployed design. The cached shell remains the offline fallback. */
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req, { cache: "reload" }).then(function (res) {
        if (isCacheablePath(url.pathname) && isPublicResponse(res)) {
          var copy = res.clone();
          caches.open(CACHE).then(function (cache) { cache.put(canonicalCacheKey(url), copy); });
        }
        return res;
      }).catch(function () {
        return caches.match(req, { ignoreSearch: true }).then(function (hit) {
          if (hit) return replayableCachedResponse(hit);
          return caches.match("index.html").then(replayableCachedResponse);
        });
      })
    );
    return;
  }

  /* Only the reviewed public app shell may enter Cache Storage. Other same-
     origin resources continue through the browser's normal network path. */
  if (!isCacheablePath(url.pathname)) return;

  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then(function (cached) {
      // Stale-while-revalidate: serve the cache immediately, refresh it in the background.
      var refresh = fetch(req).then(function (res) {
        if (isPublicResponse(res)) {
          var copy = res.clone();
          caches.open(CACHE).then(function (cache) { cache.put(canonicalCacheKey(url), copy); });
        }
        return res;
      }).catch(function () {
        // Offline and uncached: fall back to the app shell for page navigations.
        // Retired product routes are intentionally not cached or recreated
        // offline; the server remains the source of truth for their status.
        return cached;
      });
      return cached || refresh;
    })
  );
});

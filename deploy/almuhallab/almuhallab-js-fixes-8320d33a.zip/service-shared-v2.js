(function(){
  var html=document.documentElement, btn=document.getElementById('langBtn');
  if(!btn) return;
  var saved=null; try{saved=localStorage.getItem('alm-lang');}catch(e){}
  function set(l){
    html.setAttribute('data-lang',l);
    html.setAttribute('lang',l);
    html.setAttribute('dir', l==='ar' ? 'rtl' : 'ltr');
    btn.textContent = l==='ar' ? 'EN' : 'ع';
    btn.setAttribute('lang', l==='ar' ? 'en' : 'ar');
    btn.setAttribute('aria-label', l==='ar' ? 'عرض الموقع باللغة الإنجليزية' : 'View site in Arabic');
    try{localStorage.setItem('alm-lang',l);}catch(e){}
  }
  set(saved==='en'||saved==='ar' ? saved : (html.getAttribute('data-lang')==='en' ? 'en' : 'ar'));
  btn.addEventListener('click',function(){
    set(html.getAttribute('data-lang')==='ar' ? 'en' : 'ar');
  });
})();

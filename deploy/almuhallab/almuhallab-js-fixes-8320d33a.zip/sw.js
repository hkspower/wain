/* Almuhallab v201 service worker — the rebuilt public pages. */
"use strict";

var CACHE = "almuhallab-v201-js1";
/* The rebuilt public pages (one stylesheet, one home script) and what they show. Every entry
   must exist on the server: cache.addAll fails the whole install on a single 404. Scripts and the
   stylesheet are listed under the exact ?v= address the pages use, because a cached copy only
   answers a request for the same version (see the fetch handler). */
var ASSETS = [
  "index.html",
  "site-v200.css?v=20261126-rebuild1",
  "site-v200.js?v=20261126-js1",
  "service-shared-v2.js?v=20261126-js1",
  "sw-update-v201.js?v=20261126-js1",
  "sporta-logo.png",
  "sporta-og-image.png",
  "wain-logo.svg",
  "wain-preview.jpg",
  "404.html",
  "%D8%AA%D8%B5%D9%85%D9%8A%D9%85-%D9%85%D9%88%D8%A7%D9%82%D8%B9/",
  "%D8%AA%D8%B7%D8%A8%D9%8A%D9%82%D8%A7%D8%AA-%D8%A7%D9%84%D8%AC%D9%88%D8%A7%D9%84/",
  "%D9%85%D9%88%D8%B8%D9%81-%D8%B0%D9%83%D8%A7%D8%A1-%D8%A7%D8%B5%D8%B7%D9%86%D8%A7%D8%B9%D9%8A/",
  "%D8%AA%D8%B5%D9%85%D9%8A%D9%85-%D8%B4%D8%B9%D8%A7%D8%B1/",
  "icon-v2.svg",
  "favicon-v2.svg",
  "apple-touch-icon-v2.png",
  "icon-v2-192.png",
  "icon-v2-512.png",
  "icon-v2-maskable-512.png",
  "fonts/cairo-400.woff2",
  "fonts/cairo-500.woff2",
  "fonts/cairo-600.woff2",
  "fonts/cairo-700.woff2",
  "fonts/cairo-800.woff2",
  "fonts/cairo-latin.woff2",
  "fonts/chakrapetch-600.woff2",
  "fonts/chakrapetch-700.woff2",
  "fonts/jetbrainsmono-latin.woff2",
];

/* One spelling per path. Apache's own redirects write the Arabic folder names with lowercase
   escapes (%d8%aa…) and links use uppercase (%D8%AA…); both name the same page. */
function samePath(pathname) {
  try { return encodeURI(decodeURI(pathname)); } catch (e) { return pathname; }
}

var CACHE_PATHS = ASSETS.map(function (asset) {
  return samePath(new URL(asset, self.location.href).pathname);
});

function isCacheablePath(pathname) {
  return CACHE_PATHS.indexOf(pathname) !== -1;
}

function canonicalCacheKey(url) {
  /* Version query strings select fresh HTTP responses, but each reviewed
     asset owns one Cache Storage entry. Keeping the query would add another
     copy on every cache-busting visit. The response keeps the address it was
     fetched from, query included, and that is what the version check reads. */
  return url.origin + samePath(url.pathname);
}

function replayableCachedResponse(response) {
  /* Hostinger redirects /index.html to /. Cache Storage keeps that redirect
     history even though the stored response is a final 200. A navigation
     request uses redirect mode "manual", so Chromium rejects the redirected
     cached response when it is replayed offline. Rebuild only those responses
     as plain same-origin responses. Cache bodies are already decoded, hence
     the encoded size/encoding headers must not be copied. */
  if (!response || !response.redirected) return Promise.resolve(response);
  var headers = new Headers(response.headers);
  headers.delete("content-encoding");
  headers.delete("content-length");
  return response.blob().then(function (body) {
    return new Response(body, {
      status: response.status,
      statusText: response.statusText,
      headers: headers,
    });
  });
}

function isPrivatePath(pathname) {
  return pathname.endsWith(".php") ||
    pathname === "/admin.html" || pathname.startsWith("/admin/") ||
    pathname === "/mcp-admin.html" || pathname.startsWith("/mcp-admin/") ||
    pathname === "/editor.html" || pathname.startsWith("/editor/");
}

function isPublicResponse(response) {
  if (!response || !response.ok) return false;
  var control = (response.headers.get("Cache-Control") || "").toLowerCase();
  return control.indexOf("private") === -1 &&
    control.indexOf("no-store") === -1 &&
    !response.headers.has("Set-Cookie");
}

self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(CACHE).then(function (cache) {
      /* cache: "reload" goes past the browser's HTTP cache: images, fonts, scripts
         and the stylesheet are served with a week's max-age, so a plain addAll
         stored a returning visitor's stale copies under the new cache name.
         Every file is stored under its one key (canonicalCacheKey). addAll keyed
         them by their ?v= address, and the first runtime refresh then added a
         second entry for the same path, which offline matching could pick.
         All are fetched before any is stored, so one 404 still fails the install. */
      var requests = ASSETS.map(function (u) { return new Request(u, { cache: "reload" }); });
      return Promise.all(requests.map(function (r) {
        return fetch(r).then(function (res) {
          if (!res.ok) throw new Error("precache " + r.url + " " + res.status);
          return res;
        });
      })).then(function (responses) {
        return Promise.all(responses.map(function (res, i) {
          return cache.put(canonicalCacheKey(new URL(requests[i].url)), res);
        }));
      });
    }).then(function () {
      return self.skipWaiting();
    })
  );
});

self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(
        keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })
      );
    }).then(function () {
      return self.clients.claim();
    })
  );
});

self.addEventListener("fetch", function (event) {
  var req = event.request;
  if (req.method !== "GET") return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  var key = canonicalCacheKey(url);

  /* Account, administration and authorized responses must come from the server. */
  if (isPrivatePath(url.pathname) || req.headers.has("Authorization")) return;

  /* Documents are network-first so a previous offline shell cannot hide a
     newly deployed design. The cached shell remains the offline fallback. */
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req, { cache: "reload" }).then(function (res) {
        if (isCacheablePath(samePath(url.pathname)) && isPublicResponse(res)) {
          var copy = res.clone();
          caches.open(CACHE).then(function (cache) { cache.put(key, copy); });
        }
        return res;
      }).catch(function () {
        /* Offline: a page this worker holds, and the home page for the site root. Any other
           address gets the browser's own offline error. Answering it with the home page told the
           visitor a page existed under an address that may not. */
        return caches.match(url.pathname === "/" ? "index.html" : key, { ignoreSearch: true }).then(function (hit) {
          return hit ? replayableCachedResponse(hit) : Response.error();
        });
      })
    );
    return;
  }

  /* Only the reviewed public app shell may enter Cache Storage. Other same-
     origin resources continue through the browser's normal network path. */
  if (!isCacheablePath(samePath(url.pathname))) return;

  /* Stale-while-revalidate within one version. A cached copy answers only a request with the same
     query string: the pages name each script and the stylesheet with a ?v= token, and a copy from
     another token is the old file. Matching with ignoreSearch served it anyway, and the browser then
     kept it for the rest of the tab under the new address (26 Nov 2026). A copy from another
     version still answers when the network cannot. */
  var refresh = fetch(req).then(function (res) {
    if (!isPublicResponse(res)) return res;
    var copy = res.clone();
    return caches.open(CACHE)
      .then(function (cache) { return cache.put(key, copy); })
      .then(function () { return res; }, function () { return res; });
  });
  event.waitUntil(refresh.catch(function () {}));
  event.respondWith(
    caches.match(key).then(function (cached) {
      var sameVersion = !!(cached && cached.url) && new URL(cached.url).search === url.search;
      if (sameVersion) return cached;
      return refresh.catch(function () { return cached || Response.error(); });
    })
  );
});

/* almuhallab-code.com home page: the quote form and the header's current-section mark.
   The form sends nothing anywhere: it checks the fields, then opens WhatsApp with the message
   written, and the visitor presses send there. */
(function () {
  "use strict";

  /* ---------- Quote form ---------- */
  var form = document.getElementById("quote");
  if (form) {
    var name = document.getElementById("q-name");
    var email = document.getElementById("q-email");
    var type = document.getElementById("q-type");
    var msg = document.getElementById("q-msg");
    var status = form.querySelector(".form-status");
    var send = form.querySelector(".send");

    var okName = function () { return name.value.trim().length >= 2; };
    var okEmail = function () { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.value.trim()); };
    var okMsg = function () { return msg.value.trim().length >= 10; };
    var check = function (el) { return el === name ? okName() : el === email ? okEmail() : okMsg(); };
    var mark = function (el, ok) { el.setAttribute("aria-invalid", ok ? "false" : "true"); };

    [name, email, msg].forEach(function (el) {
      el.addEventListener("blur", function () { if (el.value.trim()) mark(el, check(el)); });
      el.addEventListener("input", function () {
        if (el.getAttribute("aria-invalid") === "true") mark(el, check(el));
      });
    });

    /* After a send the button stays off and the WhatsApp link carries that message. If the visitor
       then changes anything, the link would still send the old text: drop it and turn the button
       back on, so the next press sends what is on screen. */
    var unlock = function () {
      if (!send.disabled) return;
      send.disabled = false;
      var stale = form.querySelector(".golink");
      if (stale) stale.parentNode.removeChild(stale);
      if (status) status.textContent = "";
    };
    form.addEventListener("input", unlock);
    form.addEventListener("change", unlock);

    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      [name, email, msg].forEach(function (el) { mark(el, check(el)); });
      var bad = form.querySelector('[aria-invalid="true"]');
      if (bad) { bad.focus(); return; }

      var text = "مرحبا، أنا " + name.value.trim() +
        "\nنوع المشروع: " + type.value +
        "\nالبريد: " + email.value.trim() +
        "\n\n" + msg.value.trim();
      var href = "https://wa.me/96565894110?text=" + encodeURIComponent(text);

      /* Opened inside the click itself (a window opened later is what popup blockers stop),
         and a real link stays on the page for when it is stopped anyway. */
      var go = form.querySelector(".golink");
      if (!go) {
        go = document.createElement("a");
        go.className = "btn btn-ghost golink";
        go.target = "_blank";
        go.rel = "noopener";
        send.insertAdjacentElement("afterend", go);
      }
      go.href = href;
      go.textContent = "افتح واتساب إذا ما انفتح تلقائياً";
      send.disabled = true;
      if (status) status.textContent = "تمام، انفتح واتساب ورسالتك جاهزة. اضغط إرسال هناك.";
      try { window.open(href, "_blank", "noopener"); } catch (e) {}
      go.focus();
    });
  }

  /* ---------- Header: mark the section on screen ---------- */
  var links = Array.prototype.slice.call(document.querySelectorAll('.site-nav a[href^="#"], .subnav a[href^="#"]'));
  if (!links.length || !("IntersectionObserver" in window)) return;
  var ids = [];
  links.forEach(function (a) { var id = a.getAttribute("href").slice(1); if (ids.indexOf(id) === -1) ids.push(id); });
  var sections = ids.map(function (id) { return document.getElementById(id); }).filter(Boolean);
  var visible = {};
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) { visible[e.target.id] = e.isIntersecting; });
    var current = null;
    sections.forEach(function (s) { if (!current && visible[s.id]) current = s.id; });
    links.forEach(function (a) {
      if (current && a.getAttribute("href") === "#" + current) a.setAttribute("aria-current", "location");
      else a.removeAttribute("aria-current");
    });
  }, { rootMargin: "-40% 0px -55% 0px" });
  sections.forEach(function (s) { io.observe(s); });
})();

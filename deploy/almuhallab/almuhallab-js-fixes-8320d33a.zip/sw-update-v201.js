/* Keep the visible page aligned with the active worker. (sw-update-v87.js until 26 Nov 2026: the new
   name lets the previous worker, which served its cached copy of any listed script whatever its ?v=,
   hand this version to the page instead of the old one.)
   The worker takes control of open pages as soon as it activates (clients.claim), which fires
   controllerchange. Two cases must not reload, or the visitor loses what they were doing:
   - A first visit. The page was not controlled when it loaded, so it came from the network and is
     already current. Reloading it only wiped anything typed in the first seconds (26 Nov 2026).
   - A form with something typed or chosen in it. The next page the visitor opens comes through the
     new worker anyway.
   Otherwise reload once per tab, so a page that loaded under the previous worker shows the new
   deploy's files. */
(function () {
  "use strict";
  if (!("serviceWorker" in navigator)) return;

  var reloadKey = "almuhallab-v87-reloaded";
  var reloading = false;
  var wasControlled = !!navigator.serviceWorker.controller;

  function formTouched() {
    var els = document.querySelectorAll("input, textarea, select");
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.tagName === "SELECT" && el.multiple) {
        for (var j = 0; j < el.options.length; j++) {
          if (el.options[j].selected !== el.options[j].defaultSelected) return true;
        }
      } else if (el.tagName === "SELECT") {
        /* A single list with no option marked selected starts on its first option, so compare the
           index it starts on: comparing each option with its default called every such list
           changed, and blocked every reload. */
        var start = 0;
        for (var k = 0; k < el.options.length; k++) { if (el.options[k].defaultSelected) start = k; }
        if (el.options.length && el.selectedIndex !== start) return true;
      } else if (el.type === "checkbox" || el.type === "radio") {
        if (el.checked !== el.defaultChecked) return true;
      } else if (el.type !== "hidden" && el.type !== "submit" && el.type !== "button" && el.value !== el.defaultValue) {
        return true;
      }
    }
    return false;
  }
  /* Without sessionStorage there is no way to stop at one reload, so do not reload at all. */
  function reloadedThisTab() { try { return sessionStorage.getItem(reloadKey) === "1"; } catch (e) { return true; } }
  function markReloaded() { try { sessionStorage.setItem(reloadKey, "1"); } catch (e) {} }

  navigator.serviceWorker.addEventListener("controllerchange", function () {
    if (!wasControlled) { wasControlled = true; return; }
    if (reloading || reloadedThisTab() || formTouched()) return;
    reloading = true;
    markReloaded();
    location.reload();
  });

  window.addEventListener("load", function () {
    navigator.serviceWorker.register("/sw.js", { updateViaCache: "none" })
      .then(function (registration) { return registration.update(); })
      .catch(function () {});
  });
})();
